# ExamBrowser-Android
Aplikasi Exam Browser untuk Android

Demo Aplikasi : https://goo.gl/Q1c6PK
Link Aplikasi : https://goo.gl/gtK42j

Fitur Aplikasi :
- Ketika aplikasi sudah masuk tampilan web ujian, tidak bisa untuk pidah ke aplikasi lain.
- Tidak bisa ke home
- Tidak bisa screenshot
- Swipe to Refresh
